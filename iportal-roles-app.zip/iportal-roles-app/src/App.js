
import 'bootstrap/dist/css/bootstrap.min.css';

import 'bootstrap-icons/font/bootstrap-icons.css';
import './App.css';

import { BrowserRouter as Router, Switch, Route, Routes, Link } from "react-router-dom";

import Backdrop from './components/SlideDrawer/Backdrop';
import RoleComponent from './components/RolesComponent/RoleComponent';
import Sidebar from './components/Sidebar/Sidebar';
import AppsComponent from './components/AppsComponent/AppsComponent';
import AdminComponent from './components/AdminComponent/AdminComponent';
import AddAdmin from './components/AdminComponent/AddAdmin';
import AddRole from './components/RolesComponent/AddRole';
import { Component } from 'react';
// import winston from 'winston';
// import { WinstonProvider } from 'winston-react';
import LogRocket from 'logrocket';

class App extends Component {
  constructor(props) {
    super(props)
  }
  // componentWillMount(){
  //   LogRocket.init('spjqny/iportal');

  // }
render(){
  return (
   
    <Router>

      
    <Sidebar/>
   
     <Switch>
       
       <Route exact path="/roles" component={RoleComponent}/>
       <Route exact path="/apps" component={AppsComponent}/>
       <Route exact path="/addrole" component={AddRole}/>
       <Route exact path="/admin" component={AdminComponent}/>
       <Route exact path="/back" component={Backdrop}/>
       <Route exact path="/addadmin" component={AddAdmin}/>


     </Switch>
    
  
   
    </Router>

  );
}
}

export default App;
