import React  from 'react';
import ReactDom from 'react-dom';
import Sidebar from '../Sidebar';
import {render,screen} from "@testing-library/react";
import renderer from 'react-test-renderer';
import { BrowserRouter } from 'react-router-dom';
it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDom.render(<BrowserRouter><Sidebar/></BrowserRouter>, div)
});
it("render sidebar component", () =>{
    const {getByTestId} = render(<BrowserRouter><Sidebar/></BrowserRouter>);
    const input = getByTestId("sidebar");
    expect(input).toBeTruthy();
   
})
test('render Roles element', () => {
    render(<BrowserRouter><Sidebar /></BrowserRouter>);
    expect(screen.getByText('Roles')).toBeInTheDocument();
  });
test('render Home element', () => {
    render(<BrowserRouter><Sidebar /></BrowserRouter>);
    expect(screen.getByText('Home')).toBeInTheDocument();
  });
test('render Users element', () => {
    render(<BrowserRouter><Sidebar /></BrowserRouter>);
    expect(screen.getByText('Users')).toBeInTheDocument();
  });
test('render Groups element', () => {
    render(<BrowserRouter><Sidebar /></BrowserRouter>);
    expect(screen.getByText('Groups')).toBeInTheDocument();
  });
test('render Settings element', () => {
    render(<BrowserRouter><Sidebar /></BrowserRouter>);
    expect(screen.getByText('Settings')).toBeInTheDocument();
  });
test('render Apps admin centers element', () => {
    render(<BrowserRouter><Sidebar /></BrowserRouter>);
    expect(screen.getByText('Apps admin centers')).toBeInTheDocument();
  });
test('render Impersonate user element', () => {
    render(<BrowserRouter><Sidebar /></BrowserRouter>);
    expect(screen.getByText('Impersonate user')).toBeInTheDocument();
  });
it("checking width AND height of an Admin Icon", () => {
    const { getByTestId } = render(<BrowserRouter><Sidebar /></BrowserRouter>)
   expect(getByTestId('adminicon')).toHaveAttribute('width', '28');
   expect(getByTestId('adminicon')).toHaveAttribute('height', '28');
   });
   it("checking width AND height of an logo Icon", () => {
    const { getByTestId } = render(<BrowserRouter><Sidebar /></BrowserRouter>)
   expect(getByTestId('logo')).toHaveAttribute('width', '220');
   expect(getByTestId('logo')).toHaveAttribute('height', '80');
   });