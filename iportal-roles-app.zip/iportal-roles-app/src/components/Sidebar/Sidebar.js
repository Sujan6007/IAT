import React,{useState} from "react";
import { Switch, Route, Link } from "react-router-dom";
import "./Sidebar.css";
export default function Sidebar(){
    return(
        <div >
            
          
  <div class="" data-testid="sidebar">

  <nav class="navbar navbar-light bg-light shadow pb-2">
        <a class="navbar-brand" href="">
          
        </a>
        <img src={"/img/adminicon.JPG"}

data-testid="adminicon"
  width="28"
  height="28"
  float="left"
  class="d-inline-block align-top"
  alt="" />
        
        <div className="adm"> ADMINISTRATION</div>
        
        <i id="nav-icon" class="fa fa-user ms-auto" aria-hidden="true"></i>
      </nav>
  </div>
  
  <div class="sidebar-container">
  <ul class="sidebar-navigation">
    <br/>
  
    <li>
    
    <Link className="link" to=""><i class="bi bi-house-fill"></i>  Home</Link>
    </li>
    <li>
    <Link to="" className="link" ><i class="bi bi-people-fill"></i>  Users<i class="fa fa-angle-up" aria-hidden="true"></i></Link>
    </li>
    
    <li>
    <Link to="" className="link"><i class='fas fa-users'></i>  Groups < i id="drop" class="fas fa-angle-down"></i></Link>
    </li>
    <li>
      <Link to="roles" className="link"><i class="bi bi-person-plus-fill"></i>

&nbsp;  Roles </Link>
    </li>
    <li>
    <Link to="" className="link"><i class="bi bi-gear-fill"></i>   Settings < i id="drop" class="fas fa-angle-down"></i></Link>
    </li>
    <br/>
    <br/>
    <hr></hr>
    <li>
    <Link to="" className="link"><i class="fa fa-th-large" aria-hidden="true"></i> Apps admin centers</Link>
    </li>
    <li>
    <Link to="" className="link"><i class='fas fa-user-cog'></i> Impersonate user</Link>
    </li>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <img src={"/img/this.png"}
  data-testid="logo"
  width="220"
  height="80"
  alt="" />
    <div>
      
    </div>
  </ul>
</div>



        </div>

  )
}
