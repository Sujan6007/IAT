import React  from 'react';
import ReactDom from 'react-dom';
import AdminComponent from '../AdminComponent';
import {render} from "@testing-library/react";
it("renders without crashing", ()=>{

    const div = document.createElement("div");

    ReactDom.render(<AdminComponent></AdminComponent>, div)

});
it("render admin component", () =>{
    const {getByTestId} = render(<AdminComponent/>);
    const input = getByTestId("admins");
    expect(input).toBeTruthy();
   
})
it("render table", () =>{
    const {getByTestId} = render(<AdminComponent/>);
    const input = getByTestId("table");
    expect(input).toBeTruthy();
   
})
it("render thead", () =>{
    const {getByTestId} = render(<AdminComponent/>);
    const input = getByTestId("thead");
    expect(input).toBeTruthy();
   
})
it("render tbody", () =>{
    const {getByTestId} = render(<AdminComponent/>);
    const input = getByTestId("tbody");
    expect(input).toBeTruthy();
   
})