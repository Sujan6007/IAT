import React, { Component,useState } from 'react';
import AdminService from './AdminService';
import {useHistory} from 'react-router-dom';
import { Link } from 'react-router-dom';

const AddAdmin = () => {
    const[admin, setAdmin] = useState("");
    const[lastSeen,setLastseen] = useState("");
    const history = useHistory();

    const saveAdmin = (e) => {
        e.preventDefault();

        const admins = {admin,lastSeen}
        AdminService.addAdmin(admins).then((response)=>{
            console.log(response.data)
            history.push('/addadmin')
        }).catch(error=>{
            console.log(error)
        })
       
                       
    }
    
    return(
        <div>
            <br/><br/>
            <div className="container">
                <div className="row">
                    <div className="card col-md-6 offset-md-3 offset-md-3">
                        <h2 className='text-center'>Add Admin</h2>
                        <div className="card-body">
                            <form>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Admin Name :</label>
                                    <input
                                    type="text"
                                    placeholder="Enter Admin name"
                                    name="admin"
                                    className="form-control"
                                    value={admin}
                                    onChange={(e)=>setAdmin(e.target.value)}>
                                    </input>
                                </div>
                                <div className='form-group mb-2'>
                                    <label className='form-label'>Last Sign In :</label>
                                    <input
                                    type="text"
                                    placeholder="Enter last sign in"
                                    name="last_seen"
                                    className="form-control"
                                    value={lastSeen}
                                    onChange={(e)=>setLastseen(e.target.value)}>
                                    </input>
                                </div>
                                <button className='btn btn-primary btn-sm' onClick = {(e) => saveAdmin(e)}>Save</button>
                                <Link to="roles" className="btn btn-secondary btn-sm">Cancel</Link>
                            </form>
                            </div>

                    </div>

                </div>
            </div>
        </div>
    )
}


export default AddAdmin;