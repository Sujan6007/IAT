import React from "react";
import AdminService from "./AdminService";
import "./AdminComponent.css"

import { Link } from "react-router-dom";

class AdminComponent extends React.Component{
   
    constructor(props){
        super(props)
        this.state={
            admins:[]
        }
       
    }
    componentDidMount(){
        AdminService.getAdmin().then((response)=>{
            this.setState({admins:response.data})

        });
    }
   
    render(){
        return(
            <div data-testid="admins">
            <div className="Admin" >
                <h1 className="">Assigned Admins</h1>
                <table className="table table-hover" data-testid="table">
                    <thead data-testid="thead">
                        <tr>
                            {/* <td>Id</td> */}
                            <td>Admin</td>
                            <td>Last sign-in</td>
                            <td></td>
                            
                           
                        </tr>
                    </thead>
                    <tbody data-testid="tbody">
                        {
                            this.state.admins.map(
                                admin =>
                                <tr key={admin.id}>
                                    {/* <td>{role.id}</td> */}
                                    <td>{admin.admin}</td>
                                    <td>{admin.last_seen}</td>
    
                                </tr>

                            )
                        }
                    </tbody>
                </table>

            </div>
            </div>
        )
    }

}
export default AdminComponent;
    

