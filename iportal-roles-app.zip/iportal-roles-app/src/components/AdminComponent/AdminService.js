import axios from 'axios';
import AppSettings from '../../App.settings';
 class AdminService{
     getAdmin(){
        return axios.get(`${AppSettings.service_host_url}/api/admins`)
     }
    //  addAdmin(admin){
    //      return axios.post(`${AppSettings.service_host_url}/api/saveAdmin`,admin)
    //  }
   
 }
 export default new AdminService();