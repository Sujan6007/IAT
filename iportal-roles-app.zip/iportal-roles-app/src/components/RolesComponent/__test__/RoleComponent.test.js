import React  from 'react';
import ReactDom from 'react-dom';
import RoleComponent from '../RoleComponent';
import {render,screen} from "@testing-library/react";
import { BrowserRouter } from 'react-router-dom';
it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDom.render(<BrowserRouter><RoleComponent/></BrowserRouter>, div)
});
it("render roles component", () =>{
    const {getByTestId} = render(<BrowserRouter><RoleComponent/></BrowserRouter>);
    const input = getByTestId("role");
    expect(input).toBeTruthy();
})
test('render Roles element', () => {
    render(<BrowserRouter><RoleComponent/></BrowserRouter>);
    expect(screen.getByText('Roles')).toBeInTheDocument();
  });
test('render User roles element', () => {
    render(<BrowserRouter><RoleComponent/></BrowserRouter>);
    expect(screen.getByText('User roles')).toBeInTheDocument();
  });
test('render Description element', () => {
    render(<BrowserRouter><RoleComponent /></BrowserRouter>);
    expect(screen.getByText('Description')).toBeInTheDocument();
  });
it("check css properties of innerloc", () => {
    const { getByTestId } = render(<BrowserRouter><RoleComponent /></BrowserRouter>);
    expect(getByTestId("style-1")).toHaveStyle(`
    fontSize: 13px
  `);
  });
  it("check css properties of innerloc", () => {
    const { getByTestId } = render(<BrowserRouter><RoleComponent /></BrowserRouter>);
    expect(getByTestId("style-2")).toHaveStyle(`
    color: rgb(240, 236, 236)
  `);
  });
it("check css properties of innerloc", () => {
    const { getByTestId } = render(<BrowserRouter><RoleComponent /></BrowserRouter>);
    expect(getByTestId("style-3")).toHaveStyle(`
    color:#87CEEB
  `);
  });
