import axios from 'axios';
import AppSettings from '../../App.settings';


 class RolesService{
     getRoles(){
         return axios.get(`${AppSettings.service_host_url}/api/roles`)
     }
   
   
 }
 export default new RolesService();