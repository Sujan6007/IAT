import React from 'react'
import './SlideDrawer.css'
import AppService from '../AppsComponent/AppService'

import { Link } from 'react-router-dom'


import AdminService from '../AdminComponent/AdminService'
import LogService from '../Logs/LogService'


import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import 'react-tabs/style/react-tabs.css';
// import * as React from 'react';
export default class SlideDrawer extends React.Component {
   constructor(props){
      super(props)
      this.state={
          apps:[],
          admins:[],
          selected: 'Application Access'
      }
     
  }
  componentDidMount(){
      AppService.getApps().then((response)=>{
          this.setState({apps:response.data})
          LogService.infoLogs("Fetching Apps....")

      });
      
       AdminService.getAdmin().then((response)=>{
            this.setState({admins:response.data})
            LogService.infoLogs("Fetching Admins....")

        });
  }

 


   render(){
       let drawerClasses = 'side-drawer'
       if(this.props.show) {
          drawerClasses = 'side-drawer open'
       }
       return(

   
            <div className={drawerClasses} data-testid='slidedrawer'>
               <h2 className='symbol' > <Link className='arrow'><i class="bi bi-arrow-left"></i> </Link> <Link className='arrow' to="/roles"><i class="bi bi-x"></i></Link></h2>

              <br/>
              <h5 className='rolename' > {localStorage.getItem('role')}</h5>
              <br/>
          
            
              <Tabs >
    <TabList className="tab" data-testid="tablist">
      <Tab   style={{border:"none"}}  >Application Access</Tab>
      <Tab style={{border:"none"}}></Tab>
      <Tab style={{border:"none"}}>Assigned Admins</Tab>
    </TabList>

    <TabPanel className="tabs" data-testid="tabpanel">
    <div className="Apps">
      
      <table className="table table-borderless" data-testid="table">
          <thead data-testid="thead">
              <tr>
                
              </tr>
          </thead>
          <tbody data-testid="tbody">
              {
                  this.state.apps.map(
                      app =>
                      <tr key={app.id}>
                          <td><i class='fas fa-check'   ></i> &ensp; {app.appName}</td>
                      </tr>
                      

                  )
              }
              <Link className='show'>Show More (7)</Link>
          </tbody>
      </table>

  </div>
    </TabPanel>
    <TabPanel></TabPanel>
    <TabPanel className="tabs">
    <div className="Admin">
    <Link className='link' to={"addadmin"}>+ Add Admin</Link>
    <br/>
    <br/>
                
                <table className="table table-borderless">
                    
                    <thead>
                        <tr>
                            <td>Admin</td>
                            <td>Last sign-in</td>
                            <td></td>
                            
                           
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.admins.map(
                                admin =>
                                <tr key={admin.id}>
                                    <td className='adminname'>{admin.adminName}</td>
                                    <td>{admin.lastSeen}</td>
    
                                </tr>

                            )
                        }
                    </tbody>
                </table>

            </div>
      
    </TabPanel>
  </Tabs>
                 
             
            
             
          </div>
          )
        }}
        
         
