import React  from 'react';
import ReactDom from 'react-dom';
import Backdrop from '../Backdrop';
import {render} from "@testing-library/react";
it("renders without crashing", ()=>{

    const div = document.createElement("div");

    ReactDom.render(<Backdrop/>, div)

});
it("render backdrop component", () =>{
    const {getByTestId} = render(<Backdrop/>);
    const input = getByTestId("backdrop");
    expect(input).toBeTruthy();
   
})