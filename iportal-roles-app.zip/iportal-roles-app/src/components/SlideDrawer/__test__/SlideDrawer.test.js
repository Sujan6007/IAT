import React  from 'react';
import ReactDom from 'react-dom';
import SlideDrawer from '../SlideDrawer';
import {render} from "@testing-library/react";
import { BrowserRouter } from 'react-router-dom';
it("renders without crashing", ()=>{

    const div = document.createElement("div");

    ReactDom.render(<BrowserRouter><SlideDrawer/></BrowserRouter>, div)

});
it("render slidedrawer component", () =>{
    const {getByTestId} = render(<BrowserRouter><SlideDrawer/></BrowserRouter>);
    const input = getByTestId("slidedrawer");
    expect(input).toBeTruthy();
   
})
it("render tablist", () =>{
    const {getByTestId} = render(<BrowserRouter><SlideDrawer/></BrowserRouter>);
    const input = getByTestId("tablist");
    expect(input).toBeTruthy();
   
})
it("render tabpanel", () =>{
    const {getByTestId} = render(<BrowserRouter><SlideDrawer/></BrowserRouter>);
    const input = getByTestId("tabpanel");
    expect(input).toBeTruthy();
   
})
it("render table", () =>{
    const {getByTestId} = render(<BrowserRouter><SlideDrawer/></BrowserRouter>);
    const input = getByTestId("table");
    expect(input).toBeTruthy();
   
})
it("render thead ", () =>{
    const {getByTestId} = render(<BrowserRouter><SlideDrawer/></BrowserRouter>);
    const input = getByTestId("thead");
    expect(input).toBeTruthy();   
})
it("render tbody ", () =>{
    const {getByTestId} = render(<BrowserRouter><SlideDrawer/></BrowserRouter>);
    const input = getByTestId("tbody");
    expect(input).toBeTruthy();  
})