import React from 'react'
import './Backdrop.css'
export default class Backdrop extends React.Component {
  render(){
    return(
      <div data-testid="backdrop"
        className="backdrop"
        onClick={this.props.close}
      />
    )
  }
}