import axios from 'axios';
import AppSettings from '../../App.settings';


 class LogService{
     infoLogs(msg){
         return axios.post(`${AppSettings.service_host_url}/api/infologs/${msg}`)
     }
   
   
 }
 export default new LogService();
 