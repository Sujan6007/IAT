import React from "react";
import AppService from "./AppService";
import "./AppsComponent.css"
import { Link } from "react-router-dom";

class AppsComponent extends React.Component{
   
    constructor(props){
        super(props)
        this.state={
            apps:[]
        }
       
    }
    componentDidMount(){
        AppService.getApps().then((response)=>{
            this.setState({apps:response.data})

        });
    }
   
    render(){
        
        return(
            <div >
            <div className="Apps" data-testid="apps">
      
                <table className="table table-hover">
                    <thead data-testid="thead">
                        <tr>
                            {/* <td>Id</td> */}
                            <td>Application Access</td>
                            <td></td>
                            
                           
                        </tr>
                    </thead>
                    <tbody data-testid="tbody">
                        {
                            this.state.apps.map(
                                app =>
                                <tr key={app.id} >
                                    {/* <td>{role.id}</td> */}
                                    <td>{app.app}</td>
    
                                </tr>

                            )
                        }
                    </tbody>
                </table>

            </div>
            </div>
        )
    }

}
export default AppsComponent;
    

