import axios from 'axios';
import AppSettings from '../../App.settings';


 class AppsService{
     getApps(){
        return axios.get(`${AppSettings.service_host_url}/api/apps`)
     }
 }
 export default new AppsService();