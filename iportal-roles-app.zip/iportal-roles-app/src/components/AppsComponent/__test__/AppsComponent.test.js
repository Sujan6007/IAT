import React  from 'react';
import ReactDom from 'react-dom';
import AppsComponent from '../AppsComponent';
import {render} from "@testing-library/react";

it("renders without crashing", ()=>{
    const div = document.createElement("div");
    ReactDom.render(<AppsComponent></AppsComponent>, div)

});
it("render apps", () =>{
    const {getByTestId} = render(<AppsComponent/>);
    const input = getByTestId("apps");
    expect(input).toBeTruthy();
   
})
it("render thead", () =>{
    const {getByTestId} = render(<AppsComponent/>);
    const input = getByTestId("thead");
    expect(input).toBeTruthy();
   
})
it("render tbody", () =>{
    const {getByTestId} = render(<AppsComponent/>);
    const input = getByTestId("tbody");
    expect(input).toBeTruthy();
   
})

