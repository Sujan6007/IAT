package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "admin")
public class Admins {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "Admin")
	private String adminName;
	@Column(name = "last_Seen")
	private String lastSeen;
	public Admins() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Admins(long id, String adminName, String lastSeen) {
		super();
		this.id = id;
		this.adminName = adminName;
		this.lastSeen = lastSeen;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getLastSeen() {
		return lastSeen;
	}
	public void setLastSeen(String lastSeen) {
		this.lastSeen = lastSeen;
	}
	@Override
	public String toString() {
		return "Admins [id=" + id + ", adminName=" + adminName + ", lastSeen=" + lastSeen + "]";
	}
	
}
