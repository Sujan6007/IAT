package com.example.demo.constants;

public interface LoggerMessage {
	public String GET_ROLES_MSG = "Roles fetched Successfully";
	public String ADD_ROLES_MSG = "Roles added!!";
	public String GET_APPS_MSG = "Apps fetched Successfully";
	public String ADD_APPS_MSG = "Apps added!!";
	public String GET_ADMIN_MSG = "Admins fetched Successfully";
	public String ADD_ADMIN_MSG = "Admins added!!";
	public String ERROR_MSG = "Unable to fetch the data!";
	public String ENTER_GET_ROLES_SERVICE = "Entering into get roles service";
	public String EXIT_GET_ROLES_SERVICE = "Exiting get roles service";
	public String ENTER_ADD_ROLES_SERVICE = "Entering into save roles service";
	public String EXIT_ADD_ROLES_SERVICE = "Exiting save roles service";
	public String ENTER_GET_APPS_SERVICE = "Entering into get apps service";
	public String EXIT_GET_APPS_SERVICE =	"Exiting get apps service";
	public String ENTER_ADD_APPS_SERVICE = "Entering into save apps service";
	public String EXIT_ADD_APPS_SERVICE = "Exiting save apps service";
	public String ENTER_GET_ADMIN_SERVICE = "Entering into get admin service";
	public String EXIT_GET_ADMIN_SERVICE =	"Exiting get admin service";
	public String ENTER_ADD_ADMIN_SERVICE = "Entering into save admin service";
	public String EXIT_ADD_ADMIN_SERVICE = "Exiting save admin service";
	
	

}
