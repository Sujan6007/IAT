package com.example.demo.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Roles;

@Repository
@Transactional
@EnableAutoConfiguration(exclude=HibernateJpaAutoConfiguration.class)
public class RolesRepository {
	@Autowired
	private SessionFactory factory;
	
	public void saveRoles(Roles role) {
		getSession().save(role);
		
	}
	@SuppressWarnings("unchecked")
	public List<Roles> getRole() {
		return getSession().createCriteria(Roles.class).list();
	}

	private Session getSession() {
		Session session = factory.getCurrentSession();
		if (session == null) {
			session = factory.openSession();
		}
		return session;
	}


}
