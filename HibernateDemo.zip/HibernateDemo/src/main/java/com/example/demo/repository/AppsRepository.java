package com.example.demo.repository;



	import java.util.List;

	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
	import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Transactional;

	import com.example.demo.model.Apps;

	@Repository
	@Transactional
	@EnableAutoConfiguration(exclude=HibernateJpaAutoConfiguration.class)
	public class AppsRepository {
		@Autowired
		private SessionFactory factory;
		
		 public void saveApps(Apps app) {
			getSession().save(app);
			
		}
		@SuppressWarnings("unchecked")
		public List<Apps> getApp() {
			return getSession().createCriteria(Apps.class).list();
		}

		private Session getSession() {
			Session session = factory.getCurrentSession();
			if (session == null) {
				session = factory.openSession();
			}
			return session;
		}


	}

