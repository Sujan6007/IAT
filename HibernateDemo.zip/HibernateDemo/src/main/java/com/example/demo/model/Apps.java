package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "apps")
public class Apps {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	@Column(name = "appplications")
	private String appName;
	public Apps() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Apps(long id, String appName) {
		super();
		this.id = id;
		this.appName = appName;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	@Override
	public String toString() {
		return "Apps [id=" + id + ", appName=" + appName + "]";
	}
	
}