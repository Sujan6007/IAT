package com.example.demo.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.constants.LoggerMessage;
import com.example.demo.constants.URLConstants;
import com.example.demo.model.Admins;
import com.example.demo.repository.AdminsRepository;


@CrossOrigin(origins = {URLConstants.CROSS_ORIGIN_URL})
@RestController
@RequestMapping("/api")
public class AdminsController {
	@Autowired
    AdminsRepository repo;
	private static final Logger logger = Logger.getLogger(AppsController.class);

    @PostMapping( value = {URLConstants.ADD_ADMIN_URL} ,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_XML_VALUE )
    public ResponseEntity<Admins> print(@RequestBody Admins admin )
    {   
    	repo.saveAdmins(admin);
        logger.debug(LoggerMessage.ADD_ADMIN_MSG);
        return new ResponseEntity<>(admin,HttpStatus.CREATED);
    	
    }

    @GetMapping( value = {URLConstants.GET_ADMIN_URL},produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity <List<Admins>> getAdmin()
    {   
    	try {
        List<Admins> list=repo.getAdmin();
        logger.debug(LoggerMessage.GET_ADMIN_MSG);
        return new ResponseEntity<List<Admins>>(list,HttpStatus.CREATED);
    	}
    	catch (Exception e) {
    		logger.error(LoggerMessage.ERROR_MSG);
    	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
    	    }
    }

}
