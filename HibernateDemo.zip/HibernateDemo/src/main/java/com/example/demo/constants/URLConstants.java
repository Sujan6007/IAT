package com.example.demo.constants;

public interface URLConstants {
	public String CROSS_ORIGIN_URL = "http://localhost:3000";
	public String ADD_ROLE_URL = "/saveRoles";
	public String GET_ROLE_URL = "/roles";
	public String ADD_APP_URL = "/saveApps";
	public String GET_APP_URL = "/apps";
	public String ADD_ADMIN_URL = "/saveAdmin";
	public String GET_ADMIN_URL = "/admins";
	public String REACT_FRONTEND_INFO_LOGS ="/infologs/{msg}";

}
