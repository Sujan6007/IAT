package com.example.demo.controller;

import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.constants.LoggerMessage;
import com.example.demo.constants.URLConstants;
import com.example.demo.model.Roles;
import com.example.demo.repository.RolesRepository;
import com.example.demo.service.RolesService;

@CrossOrigin(origins = {URLConstants.CROSS_ORIGIN_URL})
@RestController
@RequestMapping("/api")
public class RolesController {
	@Autowired
	private RolesRepository repo;
	@Autowired
	private RolesService service;
	
	
private static final Logger logger = Logger.getLogger(RolesController.class);
	

    @PostMapping( value = {URLConstants.ADD_ROLE_URL} ,consumes = MediaType.APPLICATION_JSON_VALUE ,produces = MediaType.APPLICATION_XML_VALUE )
    public ResponseEntity<Roles> print(@RequestBody Roles role)
    {   
 
       repo.saveRoles(role);
        logger.debug(LoggerMessage.ADD_ROLES_MSG);
        return new ResponseEntity<>(role,HttpStatus.CREATED);  

    }

    
    @GetMapping( value = {URLConstants.GET_ROLE_URL} ,produces = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity <List<Roles>> getRoles()
    {  try { 
    	
        List<Roles> list=repo.getRole();
        logger.debug(LoggerMessage.GET_ROLES_MSG);
        return new ResponseEntity<List<Roles>>(list,HttpStatus.CREATED);
    }
    catch (Exception e) {
    	logger.error(LoggerMessage.ERROR_MSG);
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
    }
    
    @PostMapping(URLConstants.REACT_FRONTEND_INFO_LOGS)
    public void addLogstofile(@PathVariable String msg)
    {

        service.addlogmessage(msg);

    }

}
