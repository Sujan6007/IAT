package com.example.demo.service;

import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.stereotype.Service;

@Service
public class RolesService {
	

	public void addlogmessage(String msg) {
		 Date date = new Date();  

	        Timestamp ts=new Timestamp(date.getTime());  

	        try

	        {

	            //String filename= "C:/Users/srikar_kalle/Documents/reactlogs/info.log";

	            String filename = new SimpleDateFormat("dd-MM-yyyy'_info.log'").format(new Date());

	            FileWriter fw = new FileWriter(filename,true); //the true will append the new data

	            fw.write(ts+"\t INFO \t"+ msg + "\n");//appends the string to the file

	            fw.close();

	        }

	        catch(IOException ioe)

	        {

	            System.err.println("IOException: " + ioe.getMessage());

	        }

		
		
	}

}
